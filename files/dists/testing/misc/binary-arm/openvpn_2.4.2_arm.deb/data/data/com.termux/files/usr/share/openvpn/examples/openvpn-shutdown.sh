#!/data/data/com.termux/files/usr/bin/sh

# stop all openvpn processes

killall -TERM openvpn
